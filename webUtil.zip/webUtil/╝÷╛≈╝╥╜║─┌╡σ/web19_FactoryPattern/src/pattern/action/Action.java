package pattern.action;
/*
 * Framework 기술 
 * 
 * Struts1   --->  Struts2   ---> Spring Framework
 * 
 */
public interface Action {
	String execute(); //public abstract
}
